﻿namespace test4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pic_logo = new System.Windows.Forms.PictureBox();
            this.GroupBoxSI = new System.Windows.Forms.GroupBox();
            this.Show_result = new System.Windows.Forms.Label();
            this.Exit_button = new System.Windows.Forms.Button();
            this.Clear_buttno = new System.Windows.Forms.Button();
            this.Submit_button = new System.Windows.Forms.Button();
            this.ExtraCurricular = new System.Windows.Forms.CheckBox();
            this.List_courses = new System.Windows.Forms.ListBox();
            this.Female = new System.Windows.Forms.RadioButton();
            this.Male = new System.Windows.Forms.RadioButton();
            this.Num_age = new System.Windows.Forms.NumericUpDown();
            this.Input2 = new System.Windows.Forms.TextBox();
            this.Input1 = new System.Windows.Forms.TextBox();
            this.Age = new System.Windows.Forms.Label();
            this.Student_ID = new System.Windows.Forms.Label();
            this.student_name = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Pic_logo)).BeginInit();
            this.GroupBoxSI.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Num_age)).BeginInit();
            this.SuspendLayout();
            // 
            // Pic_logo
            // 
            this.Pic_logo.Image = global::test4.Properties.Resources.logo_1_;
            this.Pic_logo.Location = new System.Drawing.Point(10, 25);
            this.Pic_logo.Name = "Pic_logo";
            this.Pic_logo.Size = new System.Drawing.Size(182, 146);
            this.Pic_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Pic_logo.TabIndex = 0;
            this.Pic_logo.TabStop = false;
            // 
            // GroupBoxSI
            // 
            this.GroupBoxSI.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.GroupBoxSI.Controls.Add(this.Show_result);
            this.GroupBoxSI.Controls.Add(this.Pic_logo);
            this.GroupBoxSI.Controls.Add(this.Exit_button);
            this.GroupBoxSI.Controls.Add(this.Clear_buttno);
            this.GroupBoxSI.Controls.Add(this.Submit_button);
            this.GroupBoxSI.Controls.Add(this.ExtraCurricular);
            this.GroupBoxSI.Controls.Add(this.List_courses);
            this.GroupBoxSI.Controls.Add(this.Female);
            this.GroupBoxSI.Controls.Add(this.Male);
            this.GroupBoxSI.Controls.Add(this.Num_age);
            this.GroupBoxSI.Controls.Add(this.Input2);
            this.GroupBoxSI.Controls.Add(this.Input1);
            this.GroupBoxSI.Controls.Add(this.Age);
            this.GroupBoxSI.Controls.Add(this.Student_ID);
            this.GroupBoxSI.Controls.Add(this.student_name);
            this.GroupBoxSI.Location = new System.Drawing.Point(194, 12);
            this.GroupBoxSI.Name = "GroupBoxSI";
            this.GroupBoxSI.Size = new System.Drawing.Size(507, 770);
            this.GroupBoxSI.TabIndex = 1;
            this.GroupBoxSI.TabStop = false;
            this.GroupBoxSI.Text = "Student Info";
            // 
            // Show_result
            // 
            this.Show_result.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Show_result.Location = new System.Drawing.Point(60, 628);
            this.Show_result.Name = "Show_result";
            this.Show_result.Size = new System.Drawing.Size(350, 96);
            this.Show_result.TabIndex = 13;
            // 
            // Exit_button
            // 
            this.Exit_button.BackColor = System.Drawing.SystemColors.Highlight;
            this.Exit_button.Location = new System.Drawing.Point(268, 569);
            this.Exit_button.Name = "Exit_button";
            this.Exit_button.Size = new System.Drawing.Size(95, 44);
            this.Exit_button.TabIndex = 12;
            this.Exit_button.Text = "E&xit";
            this.Exit_button.UseVisualStyleBackColor = false;
            this.Exit_button.Click += new System.EventHandler(this.Exit_button_Click);
            // 
            // Clear_buttno
            // 
            this.Clear_buttno.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Clear_buttno.Location = new System.Drawing.Point(168, 569);
            this.Clear_buttno.Name = "Clear_buttno";
            this.Clear_buttno.Size = new System.Drawing.Size(94, 44);
            this.Clear_buttno.TabIndex = 11;
            this.Clear_buttno.Text = "C&lear";
            this.Clear_buttno.UseVisualStyleBackColor = false;
            this.Clear_buttno.Click += new System.EventHandler(this.Clear_buttno_Click);
            // 
            // Submit_button
            // 
            this.Submit_button.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Submit_button.Location = new System.Drawing.Point(64, 569);
            this.Submit_button.Name = "Submit_button";
            this.Submit_button.Size = new System.Drawing.Size(92, 44);
            this.Submit_button.TabIndex = 10;
            this.Submit_button.Text = "S&ubmit";
            this.Submit_button.UseVisualStyleBackColor = false;
            this.Submit_button.Click += new System.EventHandler(this.Submit_button_Click);
            // 
            // ExtraCurricular
            // 
            this.ExtraCurricular.AutoSize = true;
            this.ExtraCurricular.Location = new System.Drawing.Point(64, 502);
            this.ExtraCurricular.Name = "ExtraCurricular";
            this.ExtraCurricular.Size = new System.Drawing.Size(144, 24);
            this.ExtraCurricular.TabIndex = 9;
            this.ExtraCurricular.Text = "Extra curricular ";
            this.ExtraCurricular.UseVisualStyleBackColor = true;
            // 
            // List_courses
            // 
            this.List_courses.BackColor = System.Drawing.SystemColors.Info;
            this.List_courses.FormattingEnabled = true;
            this.List_courses.ItemHeight = 20;
            this.List_courses.Items.AddRange(new object[] {
            "1: HTML",
            "2: Python",
            "3: Java",
            "4: C#"});
            this.List_courses.Location = new System.Drawing.Point(64, 384);
            this.List_courses.Name = "List_courses";
            this.List_courses.Size = new System.Drawing.Size(299, 84);
            this.List_courses.TabIndex = 8;
            // 
            // Female
            // 
            this.Female.AutoSize = true;
            this.Female.Location = new System.Drawing.Point(214, 321);
            this.Female.Name = "Female";
            this.Female.Size = new System.Drawing.Size(87, 24);
            this.Female.TabIndex = 7;
            this.Female.TabStop = true;
            this.Female.Text = "Female";
            this.Female.UseVisualStyleBackColor = true;
            // 
            // Male
            // 
            this.Male.AutoSize = true;
            this.Male.Location = new System.Drawing.Point(64, 321);
            this.Male.Name = "Male";
            this.Male.Size = new System.Drawing.Size(68, 24);
            this.Male.TabIndex = 6;
            this.Male.TabStop = true;
            this.Male.Text = "Male";
            this.Male.UseVisualStyleBackColor = true;
            // 
            // Num_age
            // 
            this.Num_age.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Num_age.Location = new System.Drawing.Point(168, 260);
            this.Num_age.Name = "Num_age";
            this.Num_age.Size = new System.Drawing.Size(86, 26);
            this.Num_age.TabIndex = 5;
            // 
            // Input2
            // 
            this.Input2.Location = new System.Drawing.Point(168, 215);
            this.Input2.Name = "Input2";
            this.Input2.Size = new System.Drawing.Size(184, 26);
            this.Input2.TabIndex = 4;
            // 
            // Input1
            // 
            this.Input1.Location = new System.Drawing.Point(168, 172);
            this.Input1.Name = "Input1";
            this.Input1.Size = new System.Drawing.Size(184, 26);
            this.Input1.TabIndex = 3;
            // 
            // Age
            // 
            this.Age.Location = new System.Drawing.Point(22, 263);
            this.Age.Name = "Age";
            this.Age.Size = new System.Drawing.Size(119, 23);
            this.Age.TabIndex = 2;
            this.Age.Text = "Age";
            // 
            // Student_ID
            // 
            this.Student_ID.Location = new System.Drawing.Point(6, 218);
            this.Student_ID.Name = "Student_ID";
            this.Student_ID.Size = new System.Drawing.Size(119, 23);
            this.Student_ID.TabIndex = 1;
            this.Student_ID.Text = "Student ID";
            // 
            // student_name
            // 
            this.student_name.Location = new System.Drawing.Point(6, 175);
            this.student_name.Name = "student_name";
            this.student_name.Size = new System.Drawing.Size(119, 23);
            this.student_name.TabIndex = 0;
            this.student_name.Text = "Student Name";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 794);
            this.Controls.Add(this.GroupBoxSI);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Pic_logo)).EndInit();
            this.GroupBoxSI.ResumeLayout(false);
            this.GroupBoxSI.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Num_age)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Pic_logo;
        private System.Windows.Forms.GroupBox GroupBoxSI;
        private System.Windows.Forms.NumericUpDown Num_age;
        private System.Windows.Forms.TextBox Input2;
        private System.Windows.Forms.TextBox Input1;
        private System.Windows.Forms.Label Age;
        private System.Windows.Forms.Label Student_ID;
        private System.Windows.Forms.Label student_name;
        private System.Windows.Forms.CheckBox ExtraCurricular;
        private System.Windows.Forms.ListBox List_courses;
        private System.Windows.Forms.RadioButton Female;
        private System.Windows.Forms.RadioButton Male;
        private System.Windows.Forms.Label Show_result;
        private System.Windows.Forms.Button Exit_button;
        private System.Windows.Forms.Button Clear_buttno;
        private System.Windows.Forms.Button Submit_button;

    }
}

