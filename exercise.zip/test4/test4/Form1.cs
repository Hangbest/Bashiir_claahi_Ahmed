﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test4
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void Submit_button_Click(object sender, EventArgs e)
    {
        // Clear any previous error message
        Show_result.Text = "";

        // Validate name and ID (not empty)
        if (string.IsNullOrEmpty(Input1.Text) || string.IsNullOrEmpty(Input2.Text))
        {
            Show_result.Text = "Error: Please enter student name and ID.";
            return;
        }

        // Validate student ID (numeric)
        int studentID;
        if (!int.TryParse(Input2.Text, out studentID))
        {
            Show_result.Text = "Error: Student ID must be a number.";
            return;
        }

        // Validate age range (18-30)
        if (Num_age.Value < 18 || Num_age.Value > 30)
        {
            Show_result.Text = "Error: Age must be between 18 and 30.";
            return;
        }

        // Validate course selection (at least one selected)
        if (List_courses.SelectedItems.Count == 0)
        {
            Show_result.Text = "Error: Please select at least one course.";
            return;
        }

        // Validate gender selection (either radio button checked)
        if (!Male.Checked && !Female.Checked)
        {
            Show_result.Text = "Error: Please select gender.";
            return;
        }

        // All validations passed, process data (basic example)
        string selectedCourses = "";
        foreach (var item in List_courses.SelectedItems)
        {
            selectedCourses += item.ToString() + ", ";
        }
        selectedCourses = selectedCourses.TrimEnd(',', ' '); // Remove trailing comma and space

        string summary = "Student Name: " + Input1.Text + "\n" +
                         "Student ID: " + Input2.Text + "\n" +
                         "Age: " + Num_age.Value + "\n" +
                         "Gender: " + Male.Checked + Female.Checked + "\n" +
                         "courses: " + selectedCourses + "\n" +
                         "ExtraCurricular: " + ExtraCurricular.Checked;

        Show_result.Text = summary;
    }

    private void Clear_buttno_Click(object sender, EventArgs e)
    {
        Input1.Text = "";
        Input2.Text = "";
        Show_result.Text = "";
    }

    private void Exit_button_Click(object sender, EventArgs e)
    {
        this.Close();
    }
  }
}